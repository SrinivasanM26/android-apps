package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class QuestionActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    TextView lblQuestion;
    RadioButton optionA;
    RadioButton optionB;
    RadioButton optionC;
    RadioButton optionD;
    Button confirm;
    String rightAnswer;
    String Answer;
    List<Question> questions;
    int score;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        confirm = findViewById(R.id.confirm);
        lblQuestion = findViewById(R.id.lblPergunta);
        optionA = findViewById(R.id.opcaoA);
        optionB = findViewById(R.id.opcaoB);
        optionC = findViewById(R.id.opcaoC);
        optionD = findViewById(R.id.opcaoD);
        score = 0;
        radioGroup = findViewById(R.id.radioGroup);

        questions = new ArrayList<Question>(){
            {
                add(new Question("1.Which is the biggest continent in the world?", "B", "North America", "Asia","Africa", "Australia"));
                add(new Question("2.Which is the longest river in the world?", "B", "Great Ganga", "Nile","Amazon", "Niger"));
                add(new Question("3.Which is the largest ocean in the world?", "B", "Indian Ocean", "Pacific Ocean","Arctic Ocean", "Atlantic Ocean"));
                add(new Question("4.Which is India’s first super computer?", "A", "Param8000", "param80000", "param800", "param8"));
                add(new Question("5.Which bank is called bankers Bank of India?", "A", "Reserve Bank of India", "Punjab National Bank", "State Bank of India", "ICICI Bank"));
                add(new Question("6.Which is the largest animal in the world?", "C", "Shark", "Elephant", "Blue whale", "Giraffe"));
                add(new Question("7.What is the value of 8 bits?", "C", "1 Bit", "16 Bytes", "1 Byte", "1 Mega Byte"));
                add(new Question("8.FFC stands for", "B", "Foreign Finance Corporation", "Film Finance Corporation", "Federation of Football Council", "None of the above"));
                add(new Question("9.First human heart transplant operation conducted by Dr. Christiaan Barnard on Louis Washkansky, was conducted in?", "D", "1922", "1955", "1957", "1967"));
                add(new Question("10.Golf player Vijay Singh belongs to which country?", "C", "USA", "India", "Fiji", "UK"));
                add(new Question("11.In what year did the Great October Socialist Revolution take place?", "A", "1917", "1923", "1914", "1920"));
                add(new Question("12.What is the largest lake in the world?", "B", "Caspian Sea", "Baikal", "Lake Superior", "Ontario"));
                add(new Question("13.Which planet in the solar system is known as the “Red Planet”?", "C", "Venus", "Earth", "Mars", "Jupiter"));
                add(new Question("14.Who wrote the novel “War and Peace”?", "C", "Anton Chekhov", "Fyodor Dostoevsky", "Leo Tolstoy", "Ivan Turgenev"));
                add(new Question("15.What is the capital of Japan?", "B", "Beijing", "Tokyo", "Seoul", "Bangkok"));
                add(new Question("16.Which river is the longest in the world?", "C", "Amazon", "Mississippi", "Nile", "Yangtze"));
                add(new Question("17.What gas is used to extinguish fires?", "B", "Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"));
                add(new Question("18.What animal is the national symbol of Australia?", "A", "Kangaroo", "Koala", "Emu", "Crocodile"));
                add(new Question("19.Which of the following planets is not a gas giant?", "A", "Mars", "Jupiter", "Saturn", "Uranus"));
                add(new Question("20.What is the name of the process by which plants convert sunlight into energy?", "B", "Respiration", "Photosynthesis", "Oxidation", "Evolution"));
                add(new Question("21.Who wrote the “Great Gatsby” novel?", "D", "Leo Tolstoy", "Hemingway", "Stephen King", "F. Scott Fitzgerald"));
                add(new Question("22.Which is the richest country in the world?", "A", "Qatar", "Russia", "The USA", "The UAE"));
                add(new Question("23.Which county is the biggest grower of coffee?", "D", "Spain", "India", "Ethiopia", "Brazil"));
                add(new Question("24.How many bones are in the body of an adult human?", "B", "330", "206", "250", "210"));
                add(new Question("25.When do humans use more facial muscles?", "B", "While smiling", "While frowning", "While sleeping", "While talking"));
                add(new Question("26.Who wrote “Crime and Punishment”?", "B", "Leo Tolstoy", "Fyodor Dostoevsky", "Anton Chekhov", "Ivan Turgenev"));
                add(new Question("27.In what year was the United Nations (UN) founded?", "A", "1945", "1919", "1956", "1961"));
                add(new Question("28.Which city is called the “City of Winds”?", "A", "Chicago", "Seattle", "Washington", "Veliky Novgorod"));
                add(new Question("29.What animal is a symbol of peace and neutrality?", "D", "Polar bear", "White tiger", "White lion", "White crane"));
                add(new Question("30.What element is the main constituent of diamonds?", "A", "Carbon", "Oxygen", "Silver", "Gold"));

            }
        };

        loadQuestion();
    }


    @Override
    protected void onRestart(){
        super.onRestart();
        loadQuestion();
    }


    private void loadQuestion(){
        if(questions.size() > 0) {
            Question q = questions.remove(0);
            lblQuestion.setText(q.getQuestion());
            List<String> answers = q.getAnswers();

            optionA.setText(answers.get(0));
            optionB.setText(answers.get(1));
            optionC.setText(answers.get(2));
            optionD.setText(answers.get(3));

            rightAnswer = q.getRightAnswer();
        } else {
            Intent intent = new Intent(this, ShowScoreActivity.class);
            intent.putExtra("score", score);
            startActivity(intent);
            finish();
        }
    }

    public void loadAnswer(View view) {
        int op = radioGroup.getCheckedRadioButtonId();

        switch (op){
            case R.id.opcaoA:
                Answer="A";
                break;

            case R.id.opcaoB:
                Answer="B";
                break;

            case R.id.opcaoC:
                Answer="C";
                break;

            case R.id.opcaoD:
                Answer="D";
                break;

            default:
                return;

        }

        radioGroup.clearCheck();

        this.startActivity(isRightOrWrong(Answer));

    }

    private Intent isRightOrWrong(String Answer){
        Intent screen;
        if(Answer.equals(rightAnswer)) {
            this.score += 1;
            screen = new Intent(this, RightActivity.class);

        }else {
            screen = new Intent(this, WrongActivity.class);
        }

        return screen;
    }
}
